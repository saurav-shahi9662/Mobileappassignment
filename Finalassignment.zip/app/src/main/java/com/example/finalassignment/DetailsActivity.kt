package com.example.finalassignment

class DetailsActivity {
}