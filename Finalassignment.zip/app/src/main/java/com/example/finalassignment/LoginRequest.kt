package com.example.finalassignment

// Data class to represent the login request payload
data class LoginRequest(
    val username: String,  // first name
    val password: String   // student id s1234567
)
